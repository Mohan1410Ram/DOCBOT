import pandas as pd
import sys

# Using double backslashes
df = pd.read_csv('Medical_dataset\\DiseaseUMLS.csv')

def generate_concept(cui):
    return df[df['CUI'] == cui]['UMLS'].values[0]

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Please provide a CUI as an argument.")
    else:
        cui = sys.argv[1]
        print(generate_concept(cui))
